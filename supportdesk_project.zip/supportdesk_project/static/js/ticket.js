$(document).ready(function () {
    console.log('Support Ticket JavaScript is working');

    // ---------- FORM SUBMISSION VALIDATION ----------
    $('#ticketForm').submit(function (event) {
        const name = $('#id_trainee_name').val().trim();
        const email = $('#id_email').val().trim();
        const description = $('#id_description').val().trim();
        const screenshot = $('#id_screenshot')[0].files[0];
        // Name validation
        if (name.length < 3) {
            event.preventDefault();
            alert('Name must contain at least 3 characters.');
            return;
        }
        // Email validation
        if (!email.includes('@') || !email.includes('.')) {
            event.preventDefault();
            alert('Please enter a valid email address.');
            return;
        }
        // Description validation
        if (description.length < 10) {
            event.preventDefault();
            alert('Description must contain at least 10 characters.');
            return;
        }
        // Screenshot validation
        if (screenshot) {
            const allowedTypes = ['image/jpeg','image/png','image/webp'];
            if (!allowedTypes.includes(screenshot.type)) {
                event.preventDefault();
                alert('Only JPG, JPEG, PNG or WEBP files are allowed.');
                return;
            }
            if (screenshot.size > 5 * 1024 * 1024) {
                event.preventDefault();
                alert('Screenshot must be 5 MB or smaller.');
                return;
            }
        }
    });
    // ---------- SCREENSHOT PREVIEW ----------
    $('#id_screenshot').change(function () {
        const screenshot = this.files[0];
        if (screenshot) {
            $('#screenshotName').text(
                'Selected file: ' + screenshot.name
            );
        } else {
            $('#screenshotName').text('');
        }
    });
});