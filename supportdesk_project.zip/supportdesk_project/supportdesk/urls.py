from django.urls import path
from . import views

urlpatterns = [
    # Home page
    path('', views.home, name='home'),
    # Display ticket form
    path('ticket/create/', views.ticket_create, name='ticket_create'),
    # Submit ticket form
    path('ticket/submit/', views.submit_ticket, name='submit_ticket'),
    # Ticket submission success page
    path('ticket/success/', views.ticket_success, name='ticket_success'),
]