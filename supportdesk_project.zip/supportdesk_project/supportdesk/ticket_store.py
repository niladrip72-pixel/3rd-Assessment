import json
import os
from django.conf import settings
# ---------------- READ ALL TICKETS ----------------
def read_rows():
    if not os.path.exists(settings.TICKET_FILE):
        return []
    tickets = []
    with open(settings.TICKET_FILE, 'r', encoding='utf-8') as file:
        for line in file:
            if line.strip():
                tickets.append(json.loads(line))
    return tickets
# ---------------- WRITE TICKETS ----------------
def write_rows(tickets):
    os.makedirs(os.path.dirname(settings.TICKET_FILE),exist_ok=True)
    with open(settings.TICKET_FILE, 'w', encoding='utf-8') as file:
        for ticket in tickets:
            file.write(json.dumps(ticket) + '\n')
# ---------------- GET ALL ----------------
def get_all():
    return read_rows()
# ---------------- GET ONE ----------------
def get_one(pk):
    for ticket in read_rows():
        if ticket['id'] == pk:
            return ticket
    return None
# ---------------- CREATE ----------------
def create_ticket(data):
    tickets = read_rows()
    new_id = max([ticket['id'] for ticket in tickets],default=0) + 1
    ticket = {
        'id': new_id,
        'trainee_name': data['trainee_name'],
        'email': data['email'],
        'category': data['category'],
        'severity': data['severity'],
        'description': data['description'],
        'screenshot': data['screenshot'],
        'audit_id': data['audit_id']
    }
    # Append the new ticket as one JSON line
    with open(settings.TICKET_FILE,'a',encoding='utf-8') as file:
        file.write(json.dumps(ticket) + '\n')
    return ticket