import re,os
from django import forms

class TicketForm(forms.Form):
    trainee_name = forms.CharField(max_length=100,widget= forms.TextInput(attrs={
        'class' : 'form-control',
        'placeholder' : 'Enter trainee name'
    }))
    category = forms.ChoiceField(
        choices=[
            ('technical', 'Technical Issue'),
            ('course', 'Course Related'),
            ('assignment', 'Assignment Related'),
            ('other', 'Other')],
        widget=forms.Select(attrs={
            'class': 'form-select'
        }))
    severity = forms.ChoiceField(
        choices=[
            ('low', 'Low'),
            ('medium', 'Medium'),
            ('high', 'High'),
            ('critical', 'Critical')],
        widget=forms.Select(attrs={
            'class': 'form-select'
        }))
    description = forms.CharField(
        max_length=1000,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 4,
            'placeholder': 'Describe your issue'
        }))
    screenshot = forms.FileField(
        required=False,
        help_text='JPG, JPEG, PNG or WEBP. Maximum size 5 MB.',
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': '.jpg,.jpeg,.png,.webp'
        }))

    def clean_trainee_name(self):
        name = self.cleaned_data['trainee_name'].strip()
        if len(name) < 3:
            raise forms.ValidationError('Name must contain at least 3 characters.')
        if not re.match(r'^[A-Za-z ]+$', name):
            raise forms.ValidationError('Name can contain only letters and spaces.')
        return name
    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        return email
    def clean_description(self):
        description = self.cleaned_data['description'].strip()
        if len(description) < 10:
            raise forms.ValidationError('Description must contain at least 10 characters.')
        return description
    def clean_screenshot(self):
        screenshot = self.cleaned_data.get('screenshot')
        if not screenshot:
            return None
        if not re.search(r'\.(jpg|jpeg|png|webp)$', screenshot.name.lower()):
            raise forms.ValidationError('Only JPG, JPEG, PNG or WEBP files are allowed.')
        if screenshot.size > 5 * 1024 * 1024:
            raise forms.ValidationError('Screenshot must be 5 MB or smaller.')
        return screenshot