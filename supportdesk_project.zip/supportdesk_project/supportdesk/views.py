
import os
import uuid
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST
from .forms import TicketForm
from . import ticket_store
SCREENSHOT_SUBDIR = 'ticket_screenshots'
# ---------------- HOME ----------------
@require_GET
def home(request):
    return render(request, 'home.html')
# ---------------- TICKET FORM ----------------
@require_GET
def ticket_create(request):
    form = TicketForm()
    return render(request, 'ticket_form.html', {'form': form})
# ---------------- SAVE SCREENSHOT ----------------
def save_screenshot(uploaded_file):
    upload_path = os.path.join(settings.MEDIA_ROOT,SCREENSHOT_SUBDIR)
    os.makedirs(upload_path, exist_ok=True)
    extension = os.path.splitext(uploaded_file.name)[1].lower()
    filename = uuid.uuid4().hex + extension
    storage = FileSystemStorage(location=upload_path)
    saved_filename = storage.save(filename, uploaded_file)
    return f'{SCREENSHOT_SUBDIR}/{saved_filename}'
# ---------------- SUBMIT TICKET ----------------
@require_POST
def submit_ticket(request):
    form = TicketForm(request.POST, request.FILES)
    if form.is_valid():
        data = form.cleaned_data.copy()
        screenshot = data.get('screenshot')
        if screenshot:
            data['screenshot'] = save_screenshot(screenshot)
        else:
            data['screenshot'] = ''
        # Generate a unique tracking ID for this ticket
        data['audit_id'] = str(uuid.uuid4())
        # Save ticket in CSV
        ticket = ticket_store.create_ticket(data)
        return redirect(reverse('ticket_success') +'?ticket_id=' + str(ticket['id']))
    # Keep the submitted values if validation fails
    return render(request, 'ticket_form.html', {'form': form})

# ---------------- SUCCESS PAGE ----------------
@require_GET
def ticket_success(request):
    ticket_id = request.GET.get('ticket_id')
    return render(request, 'ticket_success.html', {'ticket_id': ticket_id})